﻿namespace EC.CRM.Backend.Application.Common
{
    public static class CustomClaimTypes
    {
        public const string Uid = "uid";
    }
}
