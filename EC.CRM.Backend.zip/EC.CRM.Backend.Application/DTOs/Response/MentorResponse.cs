﻿namespace EC.CRM.Backend.Application.DTOs.Response
{
    public record MentorResponse : UserInfoResponse
    {
    }
}
