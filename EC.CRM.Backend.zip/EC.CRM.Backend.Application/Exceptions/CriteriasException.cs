﻿namespace EC.CRM.Backend.Application.Exceptions
{
    public class CriteriasException : ApplicationException
    {
        public CriteriasException(string message) : base(message)
        {

        }
    }
}
