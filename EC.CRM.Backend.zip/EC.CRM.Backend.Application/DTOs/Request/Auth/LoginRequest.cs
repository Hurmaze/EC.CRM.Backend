﻿namespace EC.CRM.Backend.Application.DTOs.Request.Auth
{
    public record LoginRequest(string Email, string Password);
}
