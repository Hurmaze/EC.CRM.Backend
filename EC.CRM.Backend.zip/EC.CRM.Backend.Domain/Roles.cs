﻿namespace EC.CRM.Backend.Domain
{
    public static class Roles
    {
        public const string Director = "Director";
        public const string Mentor = "Mentor";
        public const string Student = "Student";
    }
}
