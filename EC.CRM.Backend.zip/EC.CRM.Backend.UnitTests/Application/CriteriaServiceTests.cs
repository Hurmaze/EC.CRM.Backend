﻿namespace EC.CRM.Backend.UnitTests.Application
{
    public class CriteriaServiceTests
    {
        /*private readonly string testFilePath = @"D:\VS_Projects\EC.CRM\EC.CRM.Backend\EC.CRM.Backend.UnitTests\Files\criteriasValuations2.csv";

        [Test]
        public async Task CriteriasTest()
        {
            var criteriaService = new CriteriaService();

            using (MemoryStream data = new MemoryStream())
            {
                using (Stream file = File.Open(testFilePath, FileMode.Open))
                {
                    await criteriaService.RegisterCriteriasAsync(file);
                }
            }
        }*/
    }
}
